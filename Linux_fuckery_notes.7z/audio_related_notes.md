#### Check running audio service (no root)
	systemctl --user status pulseaudio
	systemctl --user status pipewire
#### Check currently running audio service ( I guess, not sure )
	pactl info

#### Check pipewire version 
	pactl --version

#### I found this info on reddit

https://www.reddit.com/r/linuxaudio/comments/oquvki/ubuntu_2104pipewire_and_jack/

Do not start a jack server (via cadence, qjackctl or anything likie that) with
pipewire running. Use pipewire as your jack server.  Use the pipewire packages
from https://pipewire-debian.github.io/pipewire-debian/ as those available in
Ubuntu repositories are probably quite outdated. After installing those
packages pipewire 'just works' as jack for Jack applications. There will be no
'jack source' or 'jack sink' as all the ports available will be the same for
PulseAudio (what desktop applications see) and Jack ('pro audio' apps) – no
bride is needed.

Default sample rate buffer size for jack applications can be set in the
pipewire config files. That can be overridden per-application via environment
variables.

There are still some quirks, not everything works perfectly, but some things are already working much better than they ever were with Jack and PulseAudio. E.g. I can just connect and disconnect my guitar amp (functioning as USB interface) whenever I want now. With jack2 jackd would freeze, also freezing all other desktop audio, if I ever turned off my amp before stopping Jack.
