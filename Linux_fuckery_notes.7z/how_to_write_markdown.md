# Heading 1
## Heading 2
### Heading 3
#### Heading 4
##### Heading 5
###### Heading 6

Normal text can be written in normal way.

### Hyperlinks
[Go to google](https://www.google.com)

### Hyperlinks with hover caption
[Go to google](https://www.google.com "Hover text")

_Italic text here_
**Bold strong text here**
~~Strikethrough text~~

### Images
![imagename](url)

### Tables
|Name|Email|Address|
|----|-----|-----|
|John|John@example.com|Address1|

### Quotes (horizontal little bar before text)
> Your Quote looks like this.

### Code
`foreach()` method iterates each element of an array.

### Codeblock
``` Language
your code here
```

```python
print('hello world')
```

### Lists

1. item 1
2. item 2
3. item 3
	* sub item 1
	* sub item 2
* Unordered item
* Unordered item
* Unordered item

### Horizontal line
Sample text and thicker line use stars
******
Sample text and thiner line use ---
-----------------
