# How to remove GIMP logo from workspace

### Hide Wilber logo in background of workspace, default dark theme GIMP 2.10:

Open the default theme's gtkrc file (location on mac: /Applications/GIMP-2.10.app/Contents/Resources/share/gimp/2.0/themes/Dark/) in a text editor.

Find the following code (around line 360):

``` CSS
style "gimp-dark-display-style" = "gimp-dark-default-style"
{
  GimpRuler::font-scale = 0.6444
  GimpUnitComboBox::label-scale = 0.8333
  GimpScaleComboBox::label-scale = 0.8333
  GtkComboBox::arrow-size = 8
  GtkButton::inner-border = { 0, 0, 0, 0 }
  GtkButton::focus-line-width = 0
  GtkButton::focus-padding = 0
}
widget_class "*GimpDisplayShell.*" style "gimp-dark-display-style"
Within the brackets { }, add this line (change the #454545 color if needed):

fg[NORMAL] = "#454545"
Result:

style "gimp-dark-display-style" = "gimp-dark-default-style"
{
  GimpRuler::font-scale = 0.6444
  GimpUnitComboBox::label-scale = 0.8333
  GimpScaleComboBox::label-scale = 0.8333
  GtkComboBox::arrow-size = 8
  GtkButton::inner-border = { 0, 0, 0, 0 }
  GtkButton::focus-line-width = 0
  GtkButton::focus-padding = 0
  fg[NORMAL] = "#454545"
}
widget_class "*GimpDisplayShell.*" style "gimp-dark-display-style"
```

This changes the color of the Wilbur element to hex #454545, which should be
the same as the plain background color of the workspace. (If not, find out the
hex value of your background and add that number instead.)
