# Installing color profiles on Ubuntu to use in GIMP

	https://github.com/rodlie/cyan/releases/tag/1.2.2

Go to that site and download Cyan App.
That app can convert RGB to CMYK.

Go to following direcotry and copy icc color profiles.

	C:\Program File(x86)\common\adobe\color\

Copy color profile that you want to in Ubuntu.
	/usr/share/color/icc/

Open Cyan app and you can see installed color profile.
